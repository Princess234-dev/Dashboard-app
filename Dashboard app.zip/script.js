document.getElementById("sales").innerText = 120;
document.getElementById("products").innerText = 45;
document.getElementById("revenue").innerText = "$5000";